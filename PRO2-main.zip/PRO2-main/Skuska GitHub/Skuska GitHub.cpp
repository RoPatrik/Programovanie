#include <iostream>

int main()
{
    std::cout << "Filip Rosa!\n";
    std::cout << "Ahoj svet!\n";
}