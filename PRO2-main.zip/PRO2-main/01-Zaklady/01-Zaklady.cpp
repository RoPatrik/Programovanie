﻿#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World!\n"; //výpis textu do konzoly
    cout << "Moje meno je Michal." <<endl; //miesto \n môžeme použiť aj <<std::endl
    cout << "Dnes je stvrtok";

    system("pause>0");
}

